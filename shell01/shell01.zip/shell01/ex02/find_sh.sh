find . -name "*.sh" -exec basename {} .sh \;
